﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace labseventh.second.model
{
    internal class Horse : Animal
    {
        public Horse (bool canJump, string name, int age, bool reproduceInCaptivity, bool fenceWithOtherSofTheSameType) 
            : base(name + "horse", age, Nutriment.flowers, 500, reproduceInCaptivity, fenceWithOtherSofTheSameType, "Horse", false)
        {
            this.canJump = canJump;
        }
        public bool canJump { get; }

        public override string speech() => "Where is my house?";

        public override string ToString()
        {
            return base.ToString() + $", \nCan Jump: {canJump}";
        }
    }
}
