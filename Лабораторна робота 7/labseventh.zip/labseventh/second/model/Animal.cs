﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;

namespace labseventh.second.model
{
    internal abstract class Animal
    {
        public string name { get; protected set; }
        public int age { get; protected set; }
        public Nutriment nutriment { get; protected set; }
        public double amountNutrimentPerMonth { get; protected set; }
        public bool reproduceInCaptivity { get; protected set; }
        public bool fenceWithOtherSofTheSameType { get; protected set; }
        public string type { get; protected set; }
        public bool savageAndAggressive { get; protected set; }

        protected Animal(string name, int age, Nutriment nutriment, double amountNutrimentPerMonth, bool reproduceInCaptivity, bool fenceWithOtherSofTheSameType,string type, bool savageAndAggressive)
        {
            this.name = name;
            this.age = age;
            this.reproduceInCaptivity = reproduceInCaptivity;
            this.fenceWithOtherSofTheSameType = fenceWithOtherSofTheSameType;
            this.nutriment = nutriment;
            this.amountNutrimentPerMonth = amountNutrimentPerMonth;
            this.type =type;
            this.savageAndAggressive = savageAndAggressive;
        }
        public abstract string speech();
        public override string ToString()
        {
            return $"Type:{type}, \nSpeech: {speech()} \nName:{name}, \nAge: {age}, \nNutriment: {nutriment}, \nAmount Per Month: {amountNutrimentPerMonth}, \nWill it be able to reproduce in captivity or not: {reproduceInCaptivity}, \nCan it be in the same enclosure with similar ones: {fenceWithOtherSofTheSameType}, \nAgressive: {savageAndAggressive}";
        }

        public override bool Equals(object obj)
        {
            Animal other = (Animal)obj;
            return age == other.age && type == other.type;
        }

        public override int GetHashCode()
        {
            return (name, age).GetHashCode();
        }

    }
}