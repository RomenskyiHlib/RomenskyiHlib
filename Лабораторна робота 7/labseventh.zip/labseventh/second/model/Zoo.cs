﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Numerics;
using System.Text;
using System.Threading.Tasks;
using static System.Net.Mime.MediaTypeNames;

namespace labseventh.second.model
{
    internal class Zoo
    {
        public string ZooName { get; set; }
        public const int maxNumberAviaries = 6;
        private Aviary[] aviaries = new Aviary[maxNumberAviaries];
       

        public Zoo(string name)
        {
            ZooName = name;
        }

       public void AddAnimalsInAviaries(params Animal[] Animals)
        {
            foreach (Animal animal in Animals)
            {
                bool placed = false;

                for (int j = 0; j < aviaries.Length; j++)
                {
                    if (aviaries[j] == null)
                    {
                        aviaries[j] = new Aviary();
                    }
                    if (animal.savageAndAggressive)
                    {
                        if (aviaries[j].Length == 0)
                        {
                            aviaries[j].AddAnimalInAviary(animal);
                            aviaries[j].fullAviary = true;
                            placed = true;
                            break;
                        }
                        continue;
                    }

                    if (!aviaries[j].fullAviary)
                    {
                        if (aviaries[j].Length == 0)
                        {
                            aviaries[j].AddAnimalInAviary(animal);
                            placed = true;
                            break;
                        }

                        Animal firstAnimal = aviaries[j].animalsInAviary[0];

                        if (firstAnimal != null)
                        {
                            bool hasSameType = (firstAnimal.type == animal.type);
                            if (hasSameType)
                            {

                                if (animal.fenceWithOtherSofTheSameType == true)
                                {
                                    aviaries[j].AddAnimalInAviary(animal);
                                    placed = true;
                                    break;
                                }
                            }
                            else
                            {
                                aviaries[j].AddAnimalInAviary(animal);
                                placed = true;
                                break;
                            }
                        }
                    }
                }

                if (!placed)
                {
                    Console.WriteLine($"There was no room for this animal: {animal.name}");
                }
            }
        }
        public void ShowInfoAboutAviaries()
        {
            Console.WriteLine("Aviaries:");
            foreach (var aviary in aviaries)
            {
                if (aviary != null)
                    Console.WriteLine($"{aviary.ToString()}\n");
            }
        }
        public void ShowInfoAboutAnimals()
        {
            Console.WriteLine($"All Animals Information in {ZooName}");
            for (int i = 0; i < aviaries.Length; i++)
            {
                if (aviaries[i] != null)
                    foreach (var animal in aviaries[i].animalsInAviary)
                 {
                     if (animal != null)
                     Console.WriteLine($"{animal.ToString()}\n");
                 }
            }
            
        }
        public double FoodtotalPerMonthCalc()
        {
            Console.WriteLine("Information on how much feed the Zoo needs to feed the animals for a month:");
            double totalPerMonth = 0;
            Console.WriteLine($"All Animals Information in {ZooName}");
            for (int i = 0; i < aviaries.Length; i++)
            {
                if (aviaries[i] != null)
                foreach (var animal in aviaries[i].animalsInAviary)
                {
                    if (animal != null)
                    totalPerMonth += animal.amountNutrimentPerMonth;
                }
            }
            return totalPerMonth;
        }

        public void ShowSpeciesStats()
        {
            Console.WriteLine("How many animals of each type are there in the zoo?");

            int pigs = 0;
            int ducks = 0;
            int horses = 0;

            for (int i = 0; i < aviaries.Length; i++)
            {
                if (aviaries[i] != null)
                    foreach (var animal in aviaries[i].animalsInAviary)
                {
                    {
                        if (animal is Pig)
                        {
                            pigs++;
                        }
                        else if (animal is Duck)
                        {
                            ducks++;
                        }
                        else if (animal is Horse)
                        {
                            horses++;
                        }
                    }
                }
            }
            Console.WriteLine($"Pigs: {pigs}; Ducks: {ducks}; Horses: {horses}");

        }
    }
}
