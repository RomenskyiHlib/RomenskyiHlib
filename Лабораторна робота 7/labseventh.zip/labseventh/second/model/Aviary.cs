﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace labseventh.second.model
{
    internal class Aviary
    {
        public Animal[] animalsInAviary = new Animal[maxNumberOfAnimals];
        public const int maxNumberOfAnimals = 6;
        private int animalsCount = 0;
        public bool fullAviary { get; set; }

        public int Length { get { return animalsCount; } }

        public Aviary(Animal[] animalsInAviary, bool fullAviary)
        {
            this.animalsInAviary = animalsInAviary;
            this.fullAviary = fullAviary;
        }

        public Aviary() { 
            fullAviary = false;
        }

        public void AddAnimalInAviary(params Animal[] animals)
        {
            Animal[] addedAnimals = new Animal[animalsCount + animals.Length];
            if (animalsCount > 0)
            {
                Array.Copy(animalsInAviary, 0, addedAnimals, 0, animalsCount);
            }
            Array.Copy(animals, 0, addedAnimals, animalsCount, animals.Length);

            animalsCount += animals.Length;
            animalsInAviary = addedAnimals;
        }

        public override string ToString()
        {
            string infoAboutNumber = "";
                foreach (var animal in animalsInAviary)
                {
                    if (animal != null)
                        infoAboutNumber += animal.name + ", ";
                }
                return $"[{infoAboutNumber}]";
        }
    }
}
