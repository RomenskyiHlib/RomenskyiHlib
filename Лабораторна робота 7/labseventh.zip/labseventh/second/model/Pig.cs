﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace labseventh.second.model
{
    internal class Pig : Animal
    {
        public Pig(bool canFly, string name, int age, bool reproduceInCaptivity, bool fenceWithOtherSofTheSameType) 
            : base("Big " + name,age, Nutriment.dirt, 120, reproduceInCaptivity, fenceWithOtherSofTheSameType, "Pig", false)
        {
            this.canFly = canFly;
        }

        public bool canFly { get; }

        public override string speech() => "Hi, I'm Svynia";
        public override string ToString()
        {
            return base.ToString() + $", \nCan Fly: {canFly}";
        }
    }
}
