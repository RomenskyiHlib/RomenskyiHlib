﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace labseventh.second.model
{
    enum Nutriment
    {
        food,
        dirt,
        flowers,
        grain,
        water

    }
}
