﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;

namespace labseventh.first.model
{
    internal class Express : Train
    {
        public Express(string name, double maxSpeed, string station, TimeOnly departureTime, TimeOnly arrivalTime, int numberOfStations)
        : base(station, departureTime, arrivalTime, numberOfStations)
        {
            this.name = name;
            this.maxSpeed = maxSpeed;
        }
        public string name;
        public double maxSpeed;
        public string Name
        {
            get { return name; }
            set
            {
                if (value != null) name = value;
                else throw new ArgumentNullException();
            }
        }
        public double MaxSpeed
        {
            get { return maxSpeed; }
            set
            {
                if (value != null) maxSpeed = value;
                else throw new ArgumentNullException();
            }
        }
        public override double AverageTravelRange()
        {
            return base.AverageTravelRange();
        }
        public override string ToString()
        {
            return $"Express: {name}, MaxSpeed: {maxSpeed}, {base.ToString()}";
        }
        public override bool Equals(object obj)
        {
            if (obj is Express other)
            {
                return name == other.name && maxSpeed == other.maxSpeed;
            }
            return false;
        }
        public override int GetHashCode()
        {
            return HashCode.Combine(base.GetHashCode(), name, maxSpeed);
        }
    }
}
//Побудувати породжений клас  «Експрес» з додатковими полями: назва, максимальна швидкість.
