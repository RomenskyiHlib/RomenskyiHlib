﻿using labseventh;
using labseventh.first;
using labseventh.first.model;
using labseventh.second;
using labseventh.second.model;
Train[] trains = TestTrains.CreateDefaultData();
TestTrains.TrainsInfo(trains);
TestTrains.TestSystemMethods();

Zoo zoo = new Zoo("Farm");

Test.MadeNewData(zoo);
zoo.AddAnimalsInAviaries();
zoo.ShowInfoAboutAviaries();
zoo.ShowInfoAboutAnimals();
zoo.ShowSpeciesStats();
Console.WriteLine($"{zoo.FoodtotalPerMonthCalc()} kg.");
Test.TestSystemMethods(zoo);
