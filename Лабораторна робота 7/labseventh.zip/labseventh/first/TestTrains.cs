﻿using labseventh.first.model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace labseventh.first
{
    internal class TestTrains
    {  
        public static Train[] CreateDefaultData()
        {
            return new Train[]
            {
                new Train("1", new TimeOnly(10, 0), new TimeOnly(14, 0), 8),
                new Express("Null", 20, "2", new TimeOnly(23, 45), new TimeOnly(14, 0), 3)
             };
        }

        public static void TrainsInfo(Train[] trains)
        {
            Console.WriteLine("Train Information:");
            foreach (var train in trains)
            {
                Console.WriteLine(train.ToString());

                Console.WriteLine($"Average interval between stops: {train.AverageTravelRange()}");
            }

        }
        public static void TestSystemMethods()
        {
            Train train1 = new Train("3", new TimeOnly(10, 0), new TimeOnly(14, 0), 8);
            Train train2 = new Train("3", new TimeOnly(10, 0), new TimeOnly(14, 0), 8);
            Console.WriteLine($"T1 equals T2: {train1.Equals(train2)}");
            Console.WriteLine($"Hash Code 1: {train1.GetHashCode()}");
            Console.WriteLine($"Hash Code 2: {train2.GetHashCode()}");
        }
    }
}
