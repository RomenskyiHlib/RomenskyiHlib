﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace labseventh.first.model
{
    internal class Train
    {
        protected string station;
        protected TimeOnly departureTime;
        protected TimeOnly arrivalTime;
        protected int numberOfStations;

        public Train(string station, TimeOnly departureTime, TimeOnly arrivalTime, int numberOfStations)
        {
            this.station = station;
            this.departureTime = departureTime;
            this.arrivalTime = arrivalTime;
            this.numberOfStations = numberOfStations;
        }

        public string Station
        {
            get { return station; }
            set
            {
                if (value != null) station = value;
                else throw new ArgumentNullException();
            }
        }
        public TimeOnly DepartureTime
        {
            get { return departureTime; }
            set
            {
                if (value != null) departureTime = new TimeOnly(value.Hour, value.Minute);
                else throw new ArgumentNullException();
            }
        }

        public TimeOnly ArrivalTime
        {
            get { return arrivalTime; }
            set
            {
                if (value != null) arrivalTime = new TimeOnly(value.Hour, value.Minute);
                else throw new ArgumentNullException();
            }
        }
        public int NumberOfStations
        {

            get { return numberOfStations; }
            set
            {
                if (value != null) numberOfStations = value;
                else throw new ArgumentNullException();
            }
        }
        public override string ToString()
        {
            return $"Station: {station}, Departure Time: {departureTime}, Arrival Time: {arrivalTime}, Number Of Stations: {numberOfStations}";
        }

        public virtual double AverageTravelRange()
        {
            if (numberOfStations == 0) return 0;

            double totalMinutes = (ArrivalTime - DepartureTime).TotalMinutes;

            return totalMinutes / numberOfStations;
        }

        public override bool Equals(object obj)
        {
            if (obj is Train other)
            {
                return station == other.station &&
                       departureTime == other.departureTime &&
                       arrivalTime == other.arrivalTime &&
                       numberOfStations == other.numberOfStations;
            }
            return false;
        }

        public override int GetHashCode()
        {
            return (station, departureTime, arrivalTime, numberOfStations).GetHashCode();
        }
    }
}
//Створити базовий клас «Потяг» з полями: станція призначення, час відправлення, 
//час прибуття, кількість зупинок. Визначити віртуальний метод підрахунку середнього 
//інтервалу руху між зупинками.