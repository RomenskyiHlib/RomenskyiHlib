﻿using labseventh.second.model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace labseventh.second
{
    internal class Test
    {
        public static void MadeNewData(Zoo zoo)
        {
            Pig pig1 = new Pig(true, "Piginina", 20, true, true);
            Duck duck1 = new Duck("Neoduck", 2);
            Pig pig2 = new Pig(false, "Sviatopolk", 102, false, true);
            Duck duck2 = new Duck("Kachka", 999);
            Horse horse1 = new Horse(true, "Jack", 30, true, false);
            zoo.AddAnimalsInAviaries(pig1,pig2,duck1,duck2,horse1);
        }

        public static void TestSystemMethods(Zoo zoo)
        {
            Pig testAnimal1 = new Pig(true, "Piginina", 20, true, true);
            Pig testAnimal2 = new Pig(true, "Svienia", 20, true, true);

            Console.WriteLine($"Equals: {testAnimal1.Equals(testAnimal2)}");
            Console.WriteLine($"Hash Code 1: {testAnimal1.GetHashCode()}");
            Console.WriteLine($"Hash Code 2: {testAnimal2.GetHashCode()}");
        }
    }
}
