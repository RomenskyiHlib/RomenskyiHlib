﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace labseventh.second.model
{
    internal class Duck : Animal
    {
        public Duck(string name, int age)
            : base(name, age, Nutriment.grain, 9, false, false, "Duck", true)
        {
            richOrNot = true;
        }

        public bool richOrNot { get; }
        public override string speech() => "I'm not rich";
        public override string ToString()
        {
            return base.ToString() + $", \nRich: {richOrNot}";
        }
    }
}
